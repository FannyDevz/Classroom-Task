<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
    <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
    <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php 
		use Yajra\Datatables\Datatables; 
        use App\Model\User\User;
        use App\Model\StudentClass\Feed;
		use Carbon\Carbon;

		// get user auth
		$user = Auth::user();
    ?>

    <div class="table-responsive">
        <table id="tugas_siswa" class="table table-bordered data-table display nowrap" style="width:100%">
            <thead>
                <tr>
                    <th style="text-align: center" width="40%">Feed</th>
                    <th style="text-align: center">Tugas</th>
                    <th style="text-align: center" width="100">Upload</th>
                    <th style="text-align: center" width="50">Nilai</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data_tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(Feed::where('id', '=', $dt->feed_id)->value('judul')); ?></td>
                        <td><?php echo e($dt->file); ?></td>
                        <td><?php echo e(date('d-m-Y',strtotime($dt->created_at))); ?></td>
                        <td><?php echo e($dt->nilai); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" charset="utf8" src="<?= URL::to('/'); ?>/layout/assets/js/datatables.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#tugas_siswa').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\CLASS\resources\views/student_class/tugas_siswa.blade.php ENDPATH**/ ?>