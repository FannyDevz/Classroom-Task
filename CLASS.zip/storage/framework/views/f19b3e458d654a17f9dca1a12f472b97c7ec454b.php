<?php $__env->startSection('content'); ?>

<div class="limiter">
    <div class="container-register">
        <div class="wrap-register">
            <form method="POST" action="<?php echo e(route('register-siswa')); ?>" class="validate-form">

                <?php echo csrf_field(); ?>

                <span class="register100-form-title">
                    Ouroom Register
                </span>
                <div class="wrap-input100">
                    <input class="inputRegister" type="text" name="full_name" placeholder="Nama Lengkap" id="full_name" value="<?php echo e(old('full_name')); ?>">
                    <span class="focus-input100"></span>
                </div>
                <div class="wrap-input100" data-validate="Valid email is required: ex@abc.xyz">
                    <input class="inputRegister" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <span class="focus-input100"></span>
                </div>
                <div class="wrap-input100">
                    <select class="form-control" name="jenis_kelamin" style="background-color: #e6e6e6; padding: 0 20px; border-radius: 0px; height: 48px">
                        <option selected="true" disabled="disabled">Jenis Kelamin</option> 
                        <option value="laki-laki">Laki-laki</option>
                        <option value="perempuan">Perempuan</option>
                    </select>
                </div>
                <div class="wrap-input100">
                    <select class="form-control" name="angkatan" style="background-color: #e6e6e6; padding: 0 20px; border-radius: 0px; height: 48px">
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>"> <?php echo e($year); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="wrap-input100">
                    <select class="form-control" name="kelas" style="background-color: #e6e6e6; padding: 0 20px; border-radius: 0px; height: 48px">
                        <option selected="true" disabled="disabled">Kelas</option> 
                        <option value="BDP">BDP</option>
                        <option value="UPW">UPW</option>
                        <option value="ATU">ATU</option>
                    </select>
                </div>
                <div class="wrap-input100">
                    <input class="input100" type="text" name="username" placeholder="Username" id="username" value="<?php echo e(old('username')); ?>">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="Password is required">
                    <input class="input100" type="password" name="password" placeholder="Password" id="password">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="Password is required">
                    <input class="input100" type="password" name="password_confirmation" placeholder="Re-type Password" id="password_confirmation">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="container-login100-form-btn">
                    <a href="<?php echo e(route('register')); ?>">
                        <button class="login100-form-btn">
                            Register
                        </button>
                    </a>
                </div>
                <div class="text-center p-t-12">
                    <?php if($errors->any()): ?>
                        <p style="color: red"><?php echo e($errors->first()); ?></p>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <p style="color: blue"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('login.indexlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\Laravel - Copy\resources\views/auth/register.blade.php ENDPATH**/ ?>