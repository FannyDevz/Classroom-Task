<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>
    <?php if(Session::has('alert_success')): ?>
        <?php $__env->startComponent('components.alert'); ?>
            <?php $__env->slot('class'); ?>
                success
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
                Terimakasih
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('message'); ?>
                <?php echo e(session('alert_success')); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php elseif(Session::has('alert_error')): ?>
        <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('class'); ?>
                    error
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('title'); ?>
                    Cek Kembali
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('message'); ?>
                    <?php echo e(session('alert_error')); ?>

                <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php 
		use Yajra\Datatables\Datatables; 
        use App\Model\User\User;
        use Carbon\Carbon;

		// get user auth
		$user = Auth::user();
    ?>
    
    <form method="post" action="<?php echo e(route('update-tugas', ['id_kelas'=>$id_kelas, 'id_feed'=>$id_feed, 'siswa_id'=>$siswa_id])); ?>">

        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Kelas</label>
                <input type="text" class="form-control" value="<?php echo e($nama_kelas); ?>" name="nama_kelas" disabled>
            </div>
            <div class="form-group">
                <label>Feed</label>
                <input type="text" class="form-control" value="<?php echo e($nama_feed); ?>" name="feed_title" disabled>
            </div>
            <?php if($deadline != null): ?>
                <div class="form-group">
                    <label>Deadline</label>
                    <input type="text" class="form-control" value="<?php echo e(date('d-m-Y',strtotime($deadline))); ?>" name="deadline" disabled>
                </div>
            <?php endif; ?>
        <hr style="border-top: 1px solid #c6c6c6">

        <?php $__currentLoopData = $data_tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <input type="hidden" class="form-control" value="<?php echo e($dt->id); ?>" name="id_tugas">
            </div>
            <div class="ui blue segment">
                <h5>
                    <a href="<?php echo e(url($nama_kelas.'/'.$nama_feed.'/'.User::where('id', $dt->siswa_id)->value('full_name').'/'.$dt->file)); ?>" target="_blank">
                        <img height"80" width="80" src="<?php echo e(asset('asset/file_thumb.png')); ?>"> <?php echo e($dt->file); ?> </img>
                    </a>
                </h5>
            </div>
            <div class="form-group">
                <label>Nama Siswa</label>
                <input type="text" class="form-control" value="<?php echo e(User::where('id', $dt->siswa_id)->value('full_name')); ?>" name="nama_siswa" disabled>
            </div>
            <div class="form-group">
                <label>Kelas</label>
                <input type="text" class="form-control" value="<?php echo e(User::where('id', $dt->siswa_id)->value('kelas')); ?>" name="kelas" disabled>
            </div>
            <div class="form-group">
                <label>Angkatan</label>
                <input type="text" class="form-control" value="<?php echo e(User::where('id', $dt->siswa_id)->value('angkatan')); ?>" name="angkatan" disabled>
            </div>
            <div class="form-group">
                <label>Tanggal Upload</label>
                <input type="text" class="form-control" value="<?php echo e(date('d-m-Y h:i:s',strtotime($dt->created_at))); ?>" name="created_at" disabled>
            </div>
            <div class="form-group">
                <label>Nilai</label>
                <input type="text" class="form-control" value="<?php echo e($dt->nilai); ?>" name="nilai" min="0" max="100" placeholder="0-100">
                <?php if($errors->has('nilai')): ?>
                    <div class="error"><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('nilai')); ?></p></div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="form-group">
            <button type="submit" class="ui huge inverted primary button"> NILAI TUGAS </button>
            <a href="<?php echo e(route('class-feed', ['id_kelas'=>$id_kelas, 'id_feed'=>$id_feed])); ?>" class="ui huge button right floated"> KEMBALI </a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\Laravel - Copy\resources\views/student_class/assessment.blade.php ENDPATH**/ ?>