<div class="container-fluid">
    <nav class="pull-left">
        
    </nav>
    <p class="copyright pull-right">
        &copy; <script>document.write(new Date().getFullYear())</script> <a href="#">SMK Auliya Teladan Mandiri</a>
    </p>
</div><?php /**PATH C:\TA\Laravel\resources\views/include/footer.blade.php ENDPATH**/ ?>