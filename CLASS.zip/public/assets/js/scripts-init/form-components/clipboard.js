// Forms Clipboard

$( document ).ready(function() {

    new ClipboardJS('.clipboard-trigger');

});