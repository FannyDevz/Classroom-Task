<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="limiter">
    <div class="container-login">
        <div class="wrap-login">
            <div class="login100-pic js-tilt" data-tilt>
                <img src="<?= URL::to('/layout_login/images/undraw.png') ?>" alt="IMG">
            </div>
            <form method="POST" action="<?php echo e(route('login')); ?>" class="login100-form validate-form">

                <?php echo csrf_field(); ?>

                <span class="login100-form-title">
                    SMK Bhakti Mulia</br>Pare
                </span>
                <div class="wrap-input100" data-validate="Valid email is required: ex@abc.xyz">
                    <input class="input100" type="text" name="username" placeholder="Username" id="username">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="Password is required">
                    <input class="input100" type="password" name="password" placeholder="Password" id="password">
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                    </span>
                </div>
                <div class="container-login100-form-btn">
                    <button type="submit" class="login100-form-btn">
                        Login
                    </button>
                </div>

                <div class="text-center p-t-12">
                    <span class="txt1">
                        Gunakan Username dan Password yang telah diberikan
                    </span>
                    <!-- <a class="txt2" href="<?php echo e(route('show-reset')); ?>"> -->

                    <!-- </a> -->
                </div>
                <div class="container-login100-form-btn">
                    <!-- <a href="<?php echo e(route('register')); ?>"> -->
                        <!-- Hubungi Admin Jika Lupa -->
                    <!-- </a> -->
                </div>
                <div class="text-center p-t-12">
                    <?php if($errors->any()): ?>
                        <p style="color: red"><?php echo e($errors->first()); ?></p>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <p style="color: blue"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('login.indexlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\CLASS\resources\views/auth/login.blade.php ENDPATH**/ ?>