<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>

	<form method="post" action="<?php echo e(route('do-update-role', ['role_id'=>$id])); ?>">

		<?php echo csrf_field(); ?>

		<div class="form-group">
			<label>Nama Role</label>
			<input type="text" class="form-control" value="<?php echo e($data->name); ?>" name="name" disabled>
			<?php if($errors->has('name')): ?>
			    <div class="error"><p style="color: red"><span>&#42;</span> <?php echo e($errors->first('name')); ?></p></div>
			<?php endif; ?>
		</div>
		<fieldset>
		<legend>Daftar Permission</legend>
			<div class="checkbox-inline">
				<input id='check_all' name="check_all" type="checkbox">
				<label> <strong> Pilih Semua </strong></label>
			</div>
			<?php
				$i = 1;
			?>
			<hr>
			<div class="row" style="padding: 0 10px">
				<?php $__currentLoopData = $data_permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
						$i++;
					?>
					<div class="col-lg-2">
						<div class="checkbox-inline">
							<input id='<?php echo e($permission->id); ?>' name="permission[]" type="checkbox" value="<?php echo e($permission->id); ?>" <?= in_array($permission->id, $data_role_permission) ? 'checked' : '' ?> >
							<label for="permission_<?php echo e($permission->id); ?>"> <?php echo e($permission->name); ?> </label>
						</div>
					</div>
				    
					<?php if( ($i % 5) == 0): ?>
					<br>
					<hr>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
				
		</fieldset>
		<div class="form-group" style="padding-top: 20px">
			<button type="submit" class="ui huge inverted primary button"> UPDATE </button>
		</div>
	</form>
	
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script type="text/javascript">
	
$( document ).ready(function() {
	$("#check_all").click(function(){
		$('input:checkbox').not(this).prop('checked', this.checked);
	});
});
	
		
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\Laravel\resources\views/role/update.blade.php ENDPATH**/ ?>