// Guided Tours

$( document ).ready(function() {

    $('.start-tour').click(function(){
        introJs().start();
    });

});