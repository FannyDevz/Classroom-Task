<div class="alert alert-<?php echo e($class); ?>">
	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	<?php if($class == 'error'): ?>
        <p style="color: red"><?php echo e($message); ?></p>
    <?php else: ?>
        <p style="color: blue"><?php echo e($message); ?></p>
    <?php endif; ?>
</div><?php /**PATH C:\TA\Laravel\resources\views/components/alert.blade.php ENDPATH**/ ?>