<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>

<?php if(Session::has('alert_success')): ?>
    <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            success
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Terimakasih
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_success')); ?>

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php elseif(Session::has('alert_error')): ?>
    <?php $__env->startComponent('components.alert'); ?>
        <?php $__env->slot('class'); ?>
            error
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            Cek Kembali
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('message'); ?>
            <?php echo e(session('alert_error')); ?>

        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?> 
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table id="siswa_table" class="table table-bordered data-table display nowrap" style="width:100%">
            <thead>
                <tr>
                    <th style="text-align: center" width="400px">Nama</th>
                    <th style="text-align: center">Angkatan</th>
                    <th style="text-align: center">Kelas</th>
                    <th style="text-align: center" width="50px">Action</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <link rel="stylesheet" type="text/css" href="<?= URL::to('/'); ?>/layout/assets/css/jquery.dataTables.css">

    <script type="text/javascript" charset="utf8" src="<?= URL::to('/'); ?>/layout/assets/js/jquery.dataTables.js" defer></script>
    <script type="text/javascript">
        var iduser;
        var table;

        function clearAll() {
            $('#nama').val('');
            $('#angkatan').val('');
            $('#kelas').val('');
        }

        $(function() {
            table = $('#siswa_table').DataTable({
                processing: true,
                serverSide: true,
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true,
                ajax: "<?php echo e(route('siswa-class', ['id_kelas'=>$id_kelas])); ?>",
                columns: [{
                    data: 'full_name',
                    name: 'full_name'
                },
                {
                    data: 'angkatan',
                    name: 'angkatan'
                },
                {
                    data: 'kelas',
                    name: 'kelas'
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                }
                ]
            });
        });

        function btnDel(id) {
        iduser = id;
        idkelas = "<?php echo e(route('delete-siswa', ['id_kelas'=>$id_kelas])); ?>";
        swal({
            title: "Hapus User",
            text: 'Akan mengeluarkan Siswa ini dari kelas.',
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                type: 'POST',
                url: idkelas,
                data: {
                    iduser: iduser,
                    "_token": "<?php echo e(csrf_token()); ?>",
                },
                success: function(data) {
                    if (data.status != false) {
                    swal(data.message, {
                        button: false,
                        icon: "success",
                        timer: 1000
                    });
                    } else {
                    swal(data.message, {
                        button: false,
                        icon: "error",
                        timer: 1000
                    });
                    }
                    table.ajax.reload();
                },
                error: function(error) {
                    swal('Terjadi kegagalan sistem', {
                    button: false,
                    icon: "error",
                    timer: 1000
                    });
                }
                });
            }
            });
        }

        function btnTgs(id){
            iduser = id;
            idkelas = "<?php echo e($id_kelas); ?>";
            url = '/student-class/' + idkelas + '/siswa-class/' + iduser;
            window.location.href = url;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\CLASS\resources\views/student_class/siswa_class.blade.php ENDPATH**/ ?>