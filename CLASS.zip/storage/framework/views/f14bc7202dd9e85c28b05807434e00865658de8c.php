<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>
    <?php if(Session::has('alert_success')): ?>
        <?php $__env->startComponent('components.alert'); ?>
            <?php $__env->slot('class'); ?>
                success
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
                Terimakasih
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('message'); ?>
                <?php echo e(session('alert_success')); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php elseif(Session::has('alert_error')): ?>
        <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('class'); ?>
                    error
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('title'); ?>
                    Cek Kembali
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('message'); ?>
                    <?php echo e(session('alert_error')); ?>

                <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php 
		use Yajra\Datatables\Datatables; 
		use App\Model\User\User;
		use Carbon\Carbon;

		// get user auth
		$user = Auth::user();
	?>

	<?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($user->account_type == User::ACCOUNT_TYPE_CREATOR || $user->account_type == User::ACCOUNT_TYPE_ADMIN || $user->account_type == User::ACCOUNT_TYPE_TEACHER): ?>
			<a class="ui big inverted primary button btn-edit" href="<?php echo e(route('siswa-class', ['id_kelas'=>$id_kelas])); ?>">
				SISWA KELAS
			</a>
		<?php endif; ?>
		<?php if($user->account_type == User::ACCOUNT_TYPE_SISWA): ?>
			<form action="<?php echo e(route('keluar-class', ['id_kelas'=>$id_kelas])); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<button type="submit" class="ui big red button btn-edit">
					KELUAR KELAS
				</button>
			</form>
		<?php endif; ?>
			<h1 class="ui header class-attribute">
				<?php echo e($dk->class_name); ?>

				<div class="sub header sub-class-attribute"><?php echo e(User::where('id', '=', $dk->teacher_id)->value('full_name')); ?></div>
				<div class="sub header sub-class-attribute2"><?php echo e($dk->note); ?></div>
				<button id="token" class="ui big button token" value="<?php echo e($dk->token); ?>" onclick="copyToken()" onmouseout="outFunc()"><span><?php echo e($dk->token); ?></span></button>
				<?php if($user->account_type == User::ACCOUNT_TYPE_SISWA): ?>
					<a href="<?php echo e(route('rekap-tugas', ['id_kelas'=>$id_kelas])); ?>" class="ui big inverted primary button btn-edit">
						REKAP TUGAS
					</a>
				<?php endif; ?>
			</h1>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<hr style="border-top: 1px solid #c6c6c6">
	<?php if($user->account_type == User::ACCOUNT_TYPE_CREATOR || $user->account_type == User::ACCOUNT_TYPE_ADMIN || $user->account_type == User::ACCOUNT_TYPE_TEACHER): ?>
		<form method="POST" action="<?php echo e(route('upload-feed', ['id_kelas'=>$id_kelas])); ?>" class="upload-container" enctype="multipart/form-data">

			<?php echo csrf_field(); ?>

			<div id="customSegments" class="ui raised segments">
				<div class="ui segment">
					<a class="ui blue ribbon huge label">Tambahkan Sesuatu</a>
				</div>
				<div class="upload">
					<label>Judul</label>
					<input type="text" class="form-control" id="judul" name="judul">

					<input type="hidden" name="id_kelas" value="<?php echo e($id_kelas); ?>">

					<label>Kategori</label>
					<select class="form-control" name="kategori">
						<option selected="true" disabled="disabled">Pilih Kategori</option> 
						<option value="Artikel">Artikel</option>
						<option value="Tugas">Tugas</option>
						<option value="Ujian">Ujian</option>
					</select>
				</div>
				<div class="ui segments">
					<textarea class="form-control" placeholder="Detail" rows="10" id="detail" name="detail"></textarea>
				</div>
				<div class="upload">
					<label>Upload File</label>
					<input type="file" class="form-control" id="file" name="file">

					<label>Tenggat Waktu</label>
					<input type="date" min="2020-01-01" class="form-control" id="deadline" name="deadline">
				</div>
				<div class="ui segments">
					<button type="submit" class="ui primary fluid bottom huge button">
						POST
					</button>
				</div>
			</div>
		</form>
	<?php endif; ?>
	<fieldset>

	<legend><?php echo e($nama_kelas); ?></legend>
		<?php $__currentLoopData = $data_feed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $df): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div id="customSegments" class="ui raised segment">
			<div class="top-attribute">
				<?php if($df->kategori == 'Artikel'): ?>
					<a class="ui green ribbon huge label"><?php echo e($df->kategori); ?></a>
				<?php endif; ?>
				<?php if($df->kategori == 'Tugas'): ?>
					<a class="ui orange ribbon huge label"><?php echo e($df->kategori); ?></a>
				<?php endif; ?>
				<?php if($df->kategori == 'Ujian'): ?>
					<a class="ui red ribbon huge label"><?php echo e($df->kategori); ?></a>
				<?php endif; ?>
				<span class="judul"><?php echo e($df->judul); ?></span>
				<a class="ui top right attached huge image label">
					<span class="date-post"><?php echo e(date('d-m-Y',strtotime($df->created_at))); ?></span>
				</a>
			</div>
			<pre class="detail-section padding-all0"><?php echo e($df->detail); ?></pre>
			<a href="<?php echo e(route('class-feed', ['id_kelas'=>$id_kelas, 'id_feed'=>$df->id])); ?>" class="ui bottom attached big button btnfeed">
				Lihat
			</a>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
	function copyToken(elementID) {
		let element = document.getElementById("token");
		let elementText = element.textContent;
		copyText(elementText);
	}
	function copyText(text) {
		navigator.clipboard.writeText(text);
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\Laravel\resources\views/student_class/list.blade.php ENDPATH**/ ?>