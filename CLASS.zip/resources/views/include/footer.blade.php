<div class="container-fluid">
    <nav class="pull-left">

    </nav>
    <p class="copyright pull-right">
        &copy; <script>document.write(new Date().getFullYear())</script> <a href="#">SMK Bhakti Mulia Pare</a>
    </p>
</div>
