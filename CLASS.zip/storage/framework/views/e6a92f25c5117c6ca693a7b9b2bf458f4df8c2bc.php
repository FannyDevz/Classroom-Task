<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('alert'); ?>
    <?php if(Session::has('alert_success')): ?>
        <?php $__env->startComponent('components.alert'); ?>
            <?php $__env->slot('class'); ?>
                success
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('title'); ?>
                Terimakasih
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('message'); ?>
                <?php echo e(session('alert_success')); ?>

            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php elseif(Session::has('alert_error')): ?>
        <?php $__env->startComponent('components.alert'); ?>
                <?php $__env->slot('class'); ?>
                    error
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('title'); ?>
                    Cek Kembali
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('message'); ?>
                    <?php echo e(session('alert_error')); ?>

                <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php 
		use Yajra\Datatables\Datatables; 
        use App\Model\User\User;
        use Carbon\Carbon;

		// get user auth
		$user = Auth::user();
	?>
    <?php if($user->account_type == User::ACCOUNT_TYPE_CREATOR || $user->account_type == User::ACCOUNT_TYPE_ADMIN || $user->account_type == User::ACCOUNT_TYPE_TEACHER): ?>
    <form method="POST" action="<?php echo e(route('update-feed', ['id_kelas'=>$id_kelas, 'id_feed'=>$id_feed])); ?>" class="upload-container" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $feed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="customSegments" class="ui raised segments">
            <div class="ui segment">
                <a class="ui blue ribbon huge label">Edit Feed</a>
            </div>
            <div class="upload">
                <label>Judul</label>
                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e($f->judul); ?>">
                <input type="hidden" name="id_kelas" value="<?php echo e($id_kelas); ?>">
                <label>Kategori</label>
                <select class="form-control" name="kategori">
                    <option value="Artikel">Artikel</option>
                    <option value="Tugas">Tugas</option>
                    <option value="Ujian">Ujian</option>
                </select>
            </div>
            <div class="ui segments">
                <textarea class="form-control" placeholder="Detail" rows="10" id="detail" name="detail"><?php echo e($f->detail); ?></textarea>
            </div>
            <div class="upload">
                <label>Upload File</label>
                <input type="file" class="form-control" id="file" name="file" value="<?php echo e($f->file); ?>">
                <label>Tenggat Waktu</label>
                <input type="date" min="2020-01-01" class="form-control" id="deadline" name="deadline" value="<?php echo e($f->deadline); ?>">
            </div>
            <div class="ui segments">
                <div class="ui two buttons">
                    <button type="submit" class="ui right attached huge primary button btn-bottom-right">
                        UPDATE
                    </button>
                    <a href="/delete/<?php echo e($id_kelas); ?>/<?php echo e($f->id); ?>" type="button" id="hapus" class="ui left attached huge red button btn-bottom-left">
                        HAPUS
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
    <?php endif; ?>
	<fieldset>
    <?php $__currentLoopData = $feed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <legend><?php echo e($f->judul); ?></legend>
        <form method="POST" action="<?php echo e(route('upload-tugas', ['id_kelas'=>$id_kelas, 'id_feed'=>$id_feed])); ?>" id="formTugas" class="upload-container" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

            <div id="customSegments" class="ui raised segment">
                <input type="hidden" name="nama_kelas" value="<?php echo e($nama_kelas); ?>">
                <input type="hidden" name="nama_feed" value="<?php echo e($f->judul); ?>">
                <div class="top-attribute">
                    <?php if($f->kategori == 'Artikel'): ?>
                        <div class="ui green ribbon huge label"><?php echo e($f->kategori); ?></div>
                    <?php endif; ?>
                    <?php if($f->kategori == 'Tugas'): ?>
                        <div class="ui orange ribbon huge label"><?php echo e($f->kategori); ?></div>
                    <?php endif; ?>
                    <?php if($f->kategori == 'Ujian'): ?>
                        <div class="ui red ribbon huge label"><?php echo e($f->kategori); ?></div>
                    <?php endif; ?>
                    <?php if($f->deadline != null): ?>
                        <div class="ui red large label deadline"><?php echo e(date('d-m-Y',strtotime($f->deadline))); ?></div>
                    <?php endif; ?>
                    <a class="ui top right attached huge label">
                        <span class="date-post"><?php echo e(date('d-m-Y',strtotime($f->created_at))); ?></span>
                    </a>
                </div>
                <?php if($user->account_type == User::ACCOUNT_TYPE_SISWA): ?>
                    <br>
                    <span class="judul" style="font-weight:bold"><?php echo e($nilai); ?>/100</span>
                <?php endif; ?>
                <pre class="detail-section2 padding-rl0"><?php echo e($f->detail); ?></pre>
                <?php if($f->file != null): ?>
                    <div class="ui blue segment">
                        <h5>
                            <a href="<?php echo e(url($nama_kelas.'/'.$f->judul.'/'.$f->file)); ?>" target="_blank">
                                <img height"80" width="80" src="<?php echo e(asset('asset/file_thumb.png')); ?>"> 
                                    <span class="file-name"> <?php echo e($f->file); ?> </span>
                                </img>
                            </a>
                        </h5>
                    </div>
                <?php endif; ?>
                <?php if($user->account_type == User::ACCOUNT_TYPE_SISWA && $tugas == null): ?>
                    <hr style="border-top: 1px solid #c6c6c6">
                    <label>Upload File</label>
                    <div class="ui segments sfile">
                        <input type="file" id="file" name="file">
                    </div>
                    <div class="ui bottom attached huge buttons">
                        <button type="submit" class="ui button markbtn" id="tugas" value="Belum Selesai">Tandai Selesai</button>
                    </div>
                <?php endif; ?>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </fieldset>
    <?php if($user->account_type == User::ACCOUNT_TYPE_CREATOR || $user->account_type == User::ACCOUNT_TYPE_ADMIN || $user->account_type == User::ACCOUNT_TYPE_TEACHER): ?>
        <hr>
        <div class="table-responsive">
            <table id="customTable" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th style="text-align: center">Nama</th>
                        <th style="text-align: center">Tugas</th>
                        <th style="text-align: center">Tanggal</th>
                        <th style="text-align: center">Nilai</th>
                        <th style="text-align: center" width="50px">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(User::where('id', $dt->siswa_id)->value('full_name')); ?></td>
                            <td><?php echo e($dt->file); ?></td>
                            <td><?php echo e(date('d-m-Y h:i:s',strtotime($f->created_at))); ?></td>
                            <td><?php echo e($dt->nilai); ?></td>
                            <td style="text-align: center" width="90px">
                                <a href="<?php echo e(route('show-tugas', ['id_kelas'=>$id_kelas, 'id_feed'=>$id_feed, 'siswa_id'=>$dt->siswa_id])); ?>" class="ui huge inverted primary button"><span class="glyphicon glyphicon-edit"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" charset="utf8" src="<?= URL::to('/'); ?>/layout/assets/js/datatables.min.js"></script>

<script type="text/javascript">
    window.onload = function() {
        document.querySelector("#tugas").addEventListener("click", function(event) {
            event.preventDefault();
            swal({
                title: "PERHATIAN!",
                text: "Data yang telah diupload tidak bisa diganti!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnConfirm: false,
            })
            .then(
                function (isConfirm) {
                    if (isConfirm) {
                        document.querySelector("#formTugas").submit();
                    }
                },
                function() {
                    console.log('BACK');
                }
            );
        });
    };
    $(document).ready(function() {
        $('#customTable').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\TA\Laravel - Copy\resources\views/student_class/feed.blade.php ENDPATH**/ ?>