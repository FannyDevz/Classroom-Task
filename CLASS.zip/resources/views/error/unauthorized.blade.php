@extends('master')
 
@section('title', '')

@section('alert')

@endsection
 
@section('content')

<div class="alert alert-warning">
  <p style="color: red"><strong>Warning!</strong> Anda tidak mempunyai izin untuk mengakses halaman ini, silahkan menghubungi Administrator apabila anda berfikir ini merupakan sebuah kesalahan.</p>
</div>

@endsection